package com.example.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.app.Dao.CustomerDao;
import com.example.app.entity.Customer;

@Service
public class CustomerService {
	
	@Autowired
	CustomerDao customerDao;

	public Customer checkLogin(Customer customer) {
		return customerDao.save(customer);
	}

}
