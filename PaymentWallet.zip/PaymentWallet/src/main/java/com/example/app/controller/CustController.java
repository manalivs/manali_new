package com.example.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.app.entity.Customer;
import com.example.app.service.CustomerService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value="/api")
public class CustController {
	
	@Autowired
	CustomerService customerService;
	
	@PostMapping("/check")
	public Customer checkLogin(@RequestBody Customer customer) {
		return customerService.checkLogin(customer);
	}

}
