import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({

    selector: 'app-root',
    template :`
    <nav>
        <button (click)="onSubmit()" 
        class="btn btn-info btn-lg" style="margin-left: 600px; margin-top: 100px ;align-content: center; 
        background-color: #AE275F; border: none; align-self: center">Login</button>
    </nav>
        <router-outlet></router-outlet>

    `,
    styleUrls : ['./welcomePage.component.css']
               

})

export class WelcomePageComponent implements OnInit{
    

    constructor(private router: Router) {

    }

    ngOnInit(){

    }
    onSubmit(){
        this.router.navigate(['login_page']);

    }
    
}