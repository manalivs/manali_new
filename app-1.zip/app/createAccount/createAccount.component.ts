import { Component, OnInit } from '@angular/core';
import {Customer} from './customer';
import { CustomerService } from 'src/app/customer.service';

@Component({

    selector: 'app-createAcc',
    templateUrl : './createAccount.component.html',
    styleUrls : ['./createAccount.component.css']
})
export class CreateAccountComponent implements OnInit{
    customerModel = new Customer('ABC', 1111111111,'abc@gmail.com','xyz');

    onSubmit(){
        this._custService.createCustomer(this.customerModel)
      .subscribe(data => console.log(data));

    }
    

    constructor(private _custService: CustomerService){}

    ngOnInit(){

    }
}