export class Customer {
    constructor(
        public fullName : string,
        public mobileNo : number,
        public emailAddress : string,
        public password : string
    ){}
    
}