export class Login_Details {
    constructor(
        public mobileNo : number,
        public password : string,
        
    ){}
    
}