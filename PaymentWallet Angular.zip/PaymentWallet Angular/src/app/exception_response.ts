export class ExceptionResponse {
    constructor(
        public errorMessage : String
        
    ){}
    
}