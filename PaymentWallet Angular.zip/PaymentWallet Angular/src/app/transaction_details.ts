export class Transaction_Details {
   
        public payee : string
        public caption : string
        public recipient : string
        public transfer_amount : number
        public transaction_date : Date
        public transaction_time : Date
    
    
}