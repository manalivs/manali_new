import { Component, OnInit } from '@angular/core';

@Component({

    selector: 'app-welcome',
    templateUrl :'./welcomePage.component.html',
    styleUrls : ['./welcomePage.component.css']
               

})

export class WelcomePageComponent implements OnInit{
    

    constructor() {

    }

    ngOnInit(){

    }
    
}