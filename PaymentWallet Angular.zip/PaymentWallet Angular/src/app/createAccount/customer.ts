export class Customer {
    constructor(
        public mobileNo : number,
        public balance : number,
        public fullName : string,
        public emailAddress : string,
        public password : string,
        public upiId : string
    ){}
    
}